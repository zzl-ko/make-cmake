#include <stdio.h>

int main(int argc, char* argv[])
{
  // suppress warnings
  (void)argc; (void)argv;

  printf("Hello World!\n");
  return 0;
}
