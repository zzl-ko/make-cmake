#include <iostream>

int main(int argc, char* argv[])
{
  // suppress warnings
  (void)argc; (void)argv;

  std::cout << "Hello World!" << std::endl;
  return 0;
}
